# 📦 Presentation App

This app allows you to embed your Google Slides presentation in a Streamlit app.

## Demo App

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://hello-deck.streamlit.app)
