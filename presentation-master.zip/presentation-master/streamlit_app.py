import streamlit as st
import streamlit.components.v1 as components
st.title('🎈 Presentation Deck')
components.iframe("https://docs.google.com/presentation/d/e/2PACX-1vSaBx4udmh8hYvD7r8iQPMGpdrOCYPjKTo09pezMX5dyVNHJ0CBu2n8oEX-7DR-j9hGRvB-EBeI9Yaz/embed?start=false&loop=false&delayms=3000", height=480)
